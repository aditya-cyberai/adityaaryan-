import random

# Step 1: Questions data
questions = [
    {
        "question": "What is the capital of France?",
        "options": ["A. Paris", "B. London", "C. Rome"],
        "answer": "A"
    },
    {
        "question": "Which is the largest planet?",
        "options": ["A. Earth", "B. Jupiter", "C. Mars"],
        "answer": "B"
    },
    {
        "question": "Who developed Python?",
        "options": ["A. James Gosling", "B. Guido van Rossum", "C. Dennis Ritchie"],
        "answer": "B"
    },
    {
        "question": "What is 5 * 6?",
        "options": ["A. 11", "B. 30", "C. 56"],
        "answer": "B"
    }
]

# Step 2: Quiz function
def run_quiz(questions):
    score = 0
    random.shuffle(questions)  # shuffle questions every time

    for q in questions:
        print("\n" + q["question"])
        for option in q["options"]:
            print(option)
        user_answer = input("Your answer (A/B/C): ").upper()

        if user_answer == q["answer"]:
            print("✅ Correct!\n")
            score += 1
        else:
            print("❌ Wrong! Correct answer is", q["answer"], "\n")

    print("🎯 Your final score:", score, "/", len(questions))

# Step 3: Main loop
def start_game():
    username = input("Enter your name: ")
    print(f"\nWelcome {username}! 🎉 Let's start the quiz.\n")

    while True:
        run_quiz(questions)
        play_again = input("Do you want to play again? (yes/no): ").lower()
        if play_again != "yes":
            print("Thanks for playing, see you next time! 👋")
            break

# Step 4: Start the game
if __name__ == "__main__":
    start_game()