# Password Strength Checker - Trinket Friendly
# Author: Aditya Aryan

import re

# Common weak passwords list
weak_passwords = ["123456", "password", "123456789", "qwerty", "abc123", "111111"]

def check_password_strength(password):
    score = 0
    feedback = []

    # 1. Check length
    if len(password) >= 8:
        score += 2
    elif len(password) >= 5:
        score += 1
    else:
        feedback.append("Too short (use at least 8 characters)")

    # 2. Check uppercase
    if re.search(r"[A-Z]", password):
        score += 1
    else:
        feedback.append("Add uppercase letters")

    # 3. Check lowercase
    if re.search(r"[a-z]", password):
        score += 1
    else:
        feedback.append("Add lowercase letters")

    # 4. Check digits
    if re.search(r"\d", password):
        score += 1
    else:
        feedback.append("Add digits")

    # 5. Check symbols
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    else:
        feedback.append("Add symbols")

    # 6. Check if password is too common
    if password in weak_passwords:
        feedback.append("This password is too common! Avoid using it.")
        score = 1  # override

    # Final strength classification
    if score <= 2:
        strength = "Weak"
    elif score <= 4:
        strength = "Medium"
    else:
        strength = "Strong"

    return strength, feedback

# -----------------------------
print("🔐 Password Strength Checker 🔐")
print("--------------------------------")

while True:
    pwd = input("Enter a password (or type 'exit' to quit): ")
    if pwd.lower() == "exit":
        print("Exiting Password Strength Checker. Stay safe online!")
        break
    strength, tips = check_password_strength(pwd)
    print(f"Password Strength: {strength}")
    if tips:
        print("Suggestions:")
        for tip in tips:
            print(" -", tip)
    print()