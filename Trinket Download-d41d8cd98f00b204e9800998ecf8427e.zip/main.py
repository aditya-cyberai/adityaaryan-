# BMI & Health Risk Calculator
# First Bio Project 🚀

import csv

def calculate_bmi(weight, height):
    return weight / (height ** 2)

def health_risk(bmi):
    if bmi < 18.5:
        return "Underweight – Risk of nutritional deficiency"
    elif 18.5 <= bmi < 24.9:
        return "Normal – Low risk"
    elif 25 <= bmi < 29.9:
        return "Overweight – Risk of cardiovascular issues"
    else:
        return "Obese – High risk of diabetes & heart disease"

def save_to_csv(data, filename="bmi_records.csv"):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(data)

def main():
    print("Welcome to the BMI & Health Risk Calculator 🧑‍⚕️")
    name = input("Enter your name: ")
    age = int(input("Enter your age: "))
    gender = input("Enter your gender (M/F): ")
    weight = float(input("Enter your weight (kg): "))
    height = float(input("Enter your height (m): "))

    bmi = calculate_bmi(weight, height)
    risk = health_risk(bmi)

    print(f"\n{name}, your BMI is {bmi:.2f}")
    print(f"Health Risk Category: {risk}")

    # Save to CSV file
    save_to_csv([name, age, gender, weight, height, round(bmi, 2), risk])
    print("✅ Record saved in bmi_records.csv")

if __name__ == "__main__":
    main()