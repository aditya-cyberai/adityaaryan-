import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------
# 1. Create a sample dataset
# ---------------------------
data = {
    "Name": ["Aditya", "Riya", "Aman", "Sneha", "Rahul", "Meera", "Arjun", "Kavya"],
    "Age": [15, 16, 15, 17, 16, 15, 17, 16],
    "Gender": ["M", "F", "M", "F", "M", "F", "M", "F"],
    "Height_cm": [170, 155, 165, 160, 175, 150, 180, 158],
    "Weight_kg": [60, 50, 65, 55, 80, 45, 75, 48],
    "Calories_Intake": [2200, 1800, 2500, 2000, 2800, 1600, 3000, 1700]
}

df = pd.DataFrame(data)

# ---------------------------
# 2. Calculate BMI
# ---------------------------
df["Height_m"] = df["Height_cm"] / 100
df["BMI"] = df["Weight_kg"] / (df["Height_m"] ** 2)

# ---------------------------
# 3. Classify BMI category
# ---------------------------
def bmi_category(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 24.9:
        return "Normal"
    elif 25 <= bmi < 29.9:
        return "Overweight"
    else:
        return "Obese"

df["BMI_Category"] = df["BMI"].apply(bmi_category)

# ---------------------------
# 4. Print dataset
# ---------------------------
print("📊 Nutrition & BMI Dataset:\n")
print(df)

# ---------------------------
# 5. Visualization
# ---------------------------

# Pie chart of BMI categories
plt.figure(figsize=(6,6))
df["BMI_Category"].value_counts().plot.pie(autopct="%1.1f%%", colors=["lightblue","lightgreen","orange","red"])
plt.title("BMI Category Distribution")
plt.ylabel("")
plt.show()

# Bar chart of average calories intake by BMI category
plt.figure(figsize=(8,5))
df.groupby("BMI_Category")["Calories_Intake"].mean().plot(kind="bar", color="skyblue", edgecolor="black")
plt.title("Average Calorie Intake by BMI Category")
plt.xlabel("BMI Category")
plt.ylabel("Average Daily Calories")
plt.show()

# Scatter plot of BMI vs Calories Intake
plt.figure(figsize=(8,5))
plt.scatter(df["BMI"], df["Calories_Intake"], c="purple", s=80, alpha=0.7)
plt.title("BMI vs Daily Calorie Intake")
plt.xlabel("BMI")
plt.ylabel("Calories Intake")
plt.grid(True)
plt.show()