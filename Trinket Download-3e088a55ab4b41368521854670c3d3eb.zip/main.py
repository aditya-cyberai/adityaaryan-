import json
from datetime import datetime

# File to save expenses
FILE_NAME = "expenses.json"

# Load existing expenses
def load_expenses():
    try:
        with open(FILE_NAME, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

# Save expenses to file
def save_expenses(expenses):
    with open(FILE_NAME, "w") as file:
        json.dump(expenses, file, indent=4)

# Add a new expense
def add_expense(expenses, amount, category, description=""):
    expense = {
        "amount": amount,
        "category": category,
        "description": description,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    expenses.append(expense)
    save_expenses(expenses)
    print("✅ Expense added successfully!")

# View all expenses
def view_expenses(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    for i, exp in enumerate(expenses, start=1):
        print(f"{i}. {exp['date']} | {exp['category']} | {exp['amount']} | {exp['description']}")

# Get total expenses
def total_expenses(expenses):
    total = sum(exp["amount"] for exp in expenses)
    print(f"💰 Total Expenses: {total}")

# Main menu
def main():
    expenses = load_expenses()
    while True:
        print("\n=== Personal Expense Tracker ===")
        print("1. Add Expense")
        print("2. View Expenses")
        print("3. View Total")
        print("4. Exit")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            amount = float(input("Enter amount: "))
            category = input("Enter category (Food, Travel, Bills, etc.): ")
            description = input("Enter description (optional): ")
            add_expense(expenses, amount, category, description)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            total_expenses(expenses)
        elif choice == "4":
            print("Exiting... Bye!")
            break
        else:
            print("❌ Invalid choice, try again.")

if __name__ == "__main__":
    main()