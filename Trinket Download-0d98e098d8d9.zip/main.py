import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 1. Generate synthetic data
np.random.seed(42)  # reproducible

dates = pd.date_range(start='2025-01-01', end='2025-12-31')
n = len(dates)

# Temperature: average 25°C, fluctuate -5 to +5
temperature = np.random.normal(loc=25, scale=5, size=n)

# Rainfall: mostly dry, occasional heavy rain
rainfall = np.random.exponential(scale=2.0, size=n)
rainfall[np.random.rand(n) < 0.7] = 0  # 70% dry days

# Humidity: 40% to 100%
humidity = np.random.uniform(40, 100, size=n)

# Create DataFrame
weather_df = pd.DataFrame({
    'Date': dates,
    'Temperature': temperature,
    'Rainfall': rainfall,
    'Humidity': humidity
})

# 2. Calculate statistics
hottest_day = weather_df.loc[weather_df['Temperature'].idxmax()]
coldest_day = weather_df.loc[weather_df['Temperature'].idxmin()]

weather_df['Month'] = weather_df['Date'].dt.month
monthly_avg_temp = weather_df.groupby('Month')['Temperature'].mean()
monthly_total_rain = weather_df.groupby('Month')['Rainfall'].sum()

print(f"Hottest day: {hottest_day['Date'].date()} with {hottest_day['Temperature']:.1f}°C")
print(f"Coldest day: {coldest_day['Date'].date()} with {coldest_day['Temperature']:.1f}°C")
print("\nAverage temperature per month:")
print(monthly_avg_temp)
print("\nTotal rainfall per month:")
print(monthly_total_rain)

# 3. Plots
plt.figure(figsize=(12,5))
plt.plot(weather_df['Date'], weather_df['Temperature'], color='orange')
plt.title('Daily Temperature Over the Year')
plt.xlabel('Date')
plt.ylabel('Temperature (°C)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

plt.figure(figsize=(10,4))
monthly_total_rain.plot(kind='bar', color='blue')
plt.title('Total Rainfall Per Month')
plt.xlabel('Month')
plt.ylabel('Rainfall (mm)')
plt.show()

plt.figure(figsize=(10,4))
plt.hist(weather_df['Humidity'], bins=20, color='green', edgecolor='black')
plt.title('Humidity Distribution Over the Year')
plt.xlabel('Humidity (%)')
plt.ylabel('Number of Days')
plt.show()