import random

# Simple AI chatbot
print("Hello! I'm an AI Chatbot 🤖")
print("You can ask me about AI, math, or just say hi!")
print("Type 'quit' to end.\n")

# Predefined rules
responses = {
    "hi": ["Hello there!", "Hi! How are you?", "Hey!"],
    "what is ai": [
        "AI means Artificial Intelligence – teaching machines to think and learn.",
        "AI is about making computers smart.",
        "AI helps in self-driving cars, chatbots, and robotics!"
    ],
    "who created you": [
        "I was created by a Python program written by Aditya 😉",
        "A future AI engineer built me!"
    ],
    "bye": ["Goodbye!", "See you later!", "Bye! Keep learning AI!"]
}

while True:
    user_input = input("You: ").lower().strip()

    if user_input == "quit":
        print("Chatbot: Thanks for chatting, goodbye!")
        break

    # Match input with known patterns
    if user_input in responses:
        print("Chatbot:", random.choice(responses[user_input]))
    else:
        print("Chatbot: Hmm... I don’t know that yet, but I’m still learning!")